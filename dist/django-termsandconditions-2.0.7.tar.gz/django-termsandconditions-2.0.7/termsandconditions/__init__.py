"""Django Terms and Conditions Module"""
default_app_config = "termsandconditions.apps.TermsAndConditionsConfig"
